#' Builds the emission matrix of the time ecological Sequentially Markovian Coalescent
#'
#' @param mu : estimated mutation rate given prior
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Tc : coalescent times to discretize time
#' @param t : expected coalescence times of each hiddens states
#' @param beta : germination rate of vector of germination rates
#' @param FS : TRUE to use finite site model
#' @return The emission matrix
build_emission_matrix<-function(mu,mu_b,Tc,t,beta,FS=F){
  n=length(t)
  Delta=Tc[2:n]-Tc[1:(n-1)]
  g=matrix(1,length(t),3)
  if(length(beta)==1){
    beta=rep(beta,length(t))
  }
  if(!FS){
    for(k in 1:n){
      if(k>1){
        g[k,1]=exp(-2*mu*((sum((beta[1:(k-1)]+((1-beta[1:(k-1)])*mu_b))*Delta[1:(k-1)]))+(beta[k]+((1-beta[k])*mu_b))*(t[k]-Tc[k])))
      }else{
        g[k,1]=exp(-2*mu*((beta[k]+((1-beta[k])*mu_b))*(t[k])))
      }
      g[k,2]=1-g[k,1]
    }
  }else{
    for(k in 1:n){
      if(k>1){
        g[k,1]=0.25 + 0.75*exp(-4*mu*((sum((beta[1:(k-1)]+((1-beta[1:(k-1)])*mu_b))*2*Delta[1:(k-1)]))+(beta[k]+((1-beta[k])*mu_b))*(t[k]-Tc[k]))/3)
      }else{
        g[k,1]=0.25 + 0.75*exp(-4*mu*((beta[k]+((1-beta[k])*mu_b))*(t[k]))/3)
      }
      g[k,2]=1-g[k,1]
    }
  }
  return(g)
}
