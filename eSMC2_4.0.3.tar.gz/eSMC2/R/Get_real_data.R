#' Gets real data from multihetsep file
#'
#' Builds segregating matrix from a multihetsep file
#' @param path : location of the file (NA if already working in the directory of the file)
#' @param M : number of haplotypes
#' @param filename : name of the file to read
#' @param delim : delimitation in the multihetsep file
#' @export
#' @return The segregating matrix
Get_real_data<-function(path=NA,M,filename,delim=" "){
  O_total_=create_good_file(path,M,filename,delim)
  O=O_total_$output
  return(O)
}

