#' extract theta from ms format txt file
#'
#' @param file : path to the txt file
#' @return the number of segregating sites.
get_theta<-function(file){
  data=Get_data(file,heavy=T)
  theta_s=T
  while(theta_s){
    for(i in 1:length(data)){
      if(length(substr(data[[i]],1,3))>0){
        if(substr(data[[i]],1,3)[1]=="seg"){
          theta=as.numeric(strsplit(data[[i]]," ")[2])
          theta_s=F
        }
      }
    }
  }
  return(theta)
}
