#' Build signal for SMCm
#'
#' @param file_SNP : VCF file with SNP information
#' @param file_methylation : VCF file with epimuation information information
#' @param position_masked :  list containing vectors of size 2 indicating begining and end positions to mask from the sequence (positions have to be sorted).
#' @param hap : TRUE if species/data is haploid
#' @return : input data for SMCm
Get_real_methylation_data<-function(file_SNP,file_methylation,position_masked=NA ,hap=F){
  SNP_mat=list()
  epi_mat=list()
  ref_SNP=list()
  check_methy_data<-function(data){
    M=dim(data)[1]-1
    for(ii in 1:M){
      pos_0=which(as.character(data[ii,])=="0")
      if(length(pos_0)>0){
       data[ii,pos_0]="C"
      }
    }
    return(data)
  }
  for(name in 1:length(file_SNP)){
    SNP_mat[[name]]=Process_vcf_data(file_SNP[name])
    ref_SNP[[name]]=Get_vcf_ref(file_SNP[name])
    epi_mat[[name]]=Process_methylome_data(file_methylation[name],hap)
  }


    if(hap){
        output=list()
        if(is.list(SNP_mat[[1]])){
          nchr=length(SNP_mat[[1]])
        }else{
          nchr=1
        }
        if(nchr==1){
          for(name in 1:length(file_SNP)){
            SNP_mat[[name]]=list(SNP_mat[[name]])
            epi_mat[[name]]=list(epi_mat[[name]])
          }
        }
        incoherent_positions=list()
          for(chr in 1:nchr){
            incoherent_positions_v=numeric()
            print("chr:")
            print(chr)
          for (name in 1:length(file_SNP)){
            print("file:")
            print(file_SNP[name])
            if(name==1){
              # putting SNP

              output[[chr]]=SNP_mat[[name]][[chr]][1,]
              ref_chr=ref_SNP[[name]][which(as.character(ref_SNP[[name]][,1])==as.character(chr)),]

              for(nn in 2:length(file_SNP)){
                output[[chr]]=rbind(output[[chr]],ref_chr[which(as.numeric(ref_chr[,2])%in%as.numeric(SNP_mat[[name]][[chr]][dim(SNP_mat[[name]][[chr]])[1],])),3])
              }
              output[[chr]]=rbind(output[[chr]],SNP_mat[[name]][[chr]][dim(SNP_mat[[name]][[chr]])[1],])
              DO=F
                old_pos=which(epi_mat[[name]][[chr]][2,]%in%output[[chr]][dim(output[[chr]])[1],])
                old_pos_r=which(output[[chr]][dim(output[[chr]])[1],]%in%epi_mat[[name]][[chr]][2,])
                if(length(old_pos)>0){
                  if(length(which(output[[chr]][name,old_pos_r]%in%c("A","T","G")))>0){
                    incoherent_positions_v=unique(c(incoherent_positions_v,as.numeric(output[[chr]][dim(output[[chr]])[1],old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("A","T","G"))]])))
                    if(length(which(output[[chr]][name,old_pos_r]%in%c("C","0")))>0){
                      output[[chr]][name,old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("C","0"))]]=epi_mat[[name]][[chr]][1,old_pos[which(epi_mat[[name]][[chr]][2,old_pos]%in%output[[chr]][dim(output[[chr]])[1],old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("C","0"))]])]]
                    }


                  }else{
                    output[[chr]][name,old_pos_r]=epi_mat[[name]][[chr]][1,old_pos]
                  }

                  if(length(old_pos)<(dim(epi_mat[[name]][[chr]])[2]-1)){
                    DO=T
                  }
                  epi_mat[[name]][[chr]]=epi_mat[[name]][[chr]][,-old_pos]
                }
                if(DO){
                new_mat=matrix(0,ncol=length(epi_mat[[name]][[chr]][2,]),nrow=dim(output[[chr]])[1])
                new_mat[dim(new_mat)[1],]=epi_mat[[name]][[chr]][2,]
                new_mat[name,]=epi_mat[[name]][[chr]][1,]
                output[[chr]]=cbind(output[[chr]],new_mat)
                }
                output[[chr]]= output[[chr]][,order(as.numeric(output[[chr]][dim( output[[chr]])[1],]))]

            }else{

              # putting SNP

              old_pos=which(SNP_mat[[name]][[chr]][dim(SNP_mat[[name]][[chr]])[1],]%in%output[[chr]][dim(output[[chr]])[1],])
              old_pos_r=which(output[[chr]][dim(output[[chr]])[1],]%in%SNP_mat[[name]][[chr]][dim(SNP_mat[[name]][[chr]])[1],])
              DO=F
              if(length(old_pos)>0){
                output[[chr]][name,old_pos_r]=SNP_mat[[name]][[chr]][1,old_pos]
                if(length(old_pos)<(dim(SNP_mat[[name]][[chr]])[2]-1)){
                  DO=T
                }
                SNP_mat[[name]][[chr]]=SNP_mat[[name]][[chr]][,-old_pos]
              }
              if(DO){
                new_mat=matrix(0,ncol=dim(SNP_mat[[name]][[chr]])[2],nrow=dim(output[[chr]])[1])
                new_mat[dim(new_mat)[1],]=SNP_mat[[name]][[chr]][dim(SNP_mat[[name]][[chr]])[1],]
                new_mat[name,]=SNP_mat[[name]][[chr]][1,]
                ref_chr=ref_SNP[[name]][which(as.character(ref_SNP[[name]][,1])==as.character(chr)),]
                for(nn in c(1:length(file_SNP))[-name]){
                  rep_temp=ref_chr[which(as.numeric(ref_chr[,2])%in%as.numeric(new_mat[dim(new_mat)[1],])),3]
                  if(length(rep_temp)==length(new_mat[nn,])){
                    new_mat[nn,]=rep_temp
                  }else{
                    browser()
                  }

                }
                output[[chr]]=cbind(output[[chr]],new_mat)
              }

              output[[chr]]= output[[chr]][,order(as.numeric(output[[chr]][dim( output[[chr]])[1],]))]


              #putting epimutations
                old_pos=which(epi_mat[[name]][[chr]][2,]%in%output[[chr]][dim(output[[chr]])[1],])
                old_pos_r=which(output[[chr]][dim(output[[chr]])[1],]%in%epi_mat[[name]][[chr]][2,])
                DO=F
                if(length(old_pos)>0){

                  if(length(which(output[[chr]][name,old_pos_r]%in%c("A","T","G")))>0){
                    incoherent_positions_v=unique(c(incoherent_positions_v,as.numeric(output[[chr]][dim(output[[chr]])[1],old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("A","T","G"))]])))
                    if(length(which(output[[chr]][name,old_pos_r]%in%c("C","0")))>0){
                      output[[chr]][name,old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("C","0"))]]=epi_mat[[name]][[chr]][1,old_pos[which(epi_mat[[name]][[chr]][2,old_pos]%in%output[[chr]][dim(output[[chr]])[1],old_pos_r[which(output[[chr]][name,old_pos_r]%in%c("C","0"))]])]]
                    }

                    }else{
                    output[[chr]][name,old_pos_r]=epi_mat[[name]][[chr]][1,old_pos]
                  }

                  if(length(old_pos)<(dim(epi_mat[[name]][[chr]])[2]-1)){
                    DO=T
                  }
                  epi_mat[[name]][[chr]]=epi_mat[[name]][[chr]][,-old_pos]

                }
                if(DO){
                new_mat=matrix(0,ncol=dim(epi_mat[[name]][[chr]])[2],nrow=dim(output[[chr]])[1])
                new_mat[dim(new_mat)[1],]=epi_mat[[name]][[chr]][2,]
                new_mat[name,]=epi_mat[[name]][[chr]][1,]
                output[[chr]]=cbind(output[[chr]],new_mat)
                }
                output[[chr]]= output[[chr]][,order(as.numeric(output[[chr]][dim( output[[chr]])[1],]))]

            }
          }
          output[[chr]]=check_methy_data(output[[chr]])
          output[[chr]]=rbind(output[[chr]][-dim(output[[chr]])[1],], as.numeric(output[[chr]][dim(output[[chr]])[1],])-c(1,as.numeric(output[[chr]][dim(output[[chr]])[1],-dim(output[[chr]])[2]])),as.numeric(output[[chr]][dim(output[[chr]])[1],]))
          incoherent_positions[[chr]]=incoherent_positions_v

          }


    }else{

    }


  if(!is.na(position_masked)){
   for(ccc in 1:length(position_masked)){
     if(as.numeric(position_masked[[ccc]][1])<as.numeric(output[[chr]][dim(output[[chr]])[1],1])){

       if(as.numeric(position_masked[[ccc]][2])>as.numeric(output[[chr]][dim(output[[chr]])[1],dim(output[[chr]])[2]])){
        stop('All sequence is masked :/')
       }else{
         p_2=min(which(output[[chr]][dim(output[[chr]])[1],]>position_masked[[ccc]][2]))
         output[[chr]][(dim(output[[chr]])[1]-1),p_2]=as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_2])-as.numeric(position_masked[[ccc]][2])
         if(p_2>1){
         output[[chr]]=output[[chr]][,-c(1:(p_2-1))]
         }
       }
     }else{
       p_1=max(which(output[[chr]][dim(output[[chr]])[1],]<position_masked[[ccc]][1]))
       if(as.numeric(position_masked[[ccc]][2])>as.numeric(output[[chr]][dim(output[[chr]])[1],dim(output[[chr]])[2]])){
         output[[chr]]=output[[chr]][,-c(p_1:(dim(output[[chr]])[2]))]
       }else{
         p_2=min(which(output[[chr]][dim(output[[chr]])[1],]>position_masked[[ccc]][2]))
         output[[chr]][(dim(output[[chr]])[1]-1),p_2]=as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_2])-as.numeric(position_masked[[ccc]][2])+as.numeric(position_masked[[ccc]][1])-as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_1])
         if(p_2==(p_1+1)){
           output[[chr]]=output[[chr]][,-(p_1+1)]
         }else{
           if(p_2>(p_1+2)){
             output[[chr]]=output[[chr]][,-c((p_1+1):(p_2-1))]
           }
         }

       }

     }



   }
  }


  return(list(output,incoherent_positions))
}
