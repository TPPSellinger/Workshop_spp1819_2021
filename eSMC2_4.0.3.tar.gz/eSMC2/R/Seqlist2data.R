#' Transforms a ms ouput file in a segregating sites matrix
#'
#' Read a ms outputfile and build a Segregating site matrix
#' @param DNAfile : the file
#' @param L : sequence length
#' @param M : number of individual
#' @param s : number of repetition/Different analysis
#' @return The segregating sites matrix.
Seqlist2data<-function(DNAfile,L,M,s){
  Output=list()
  vect_t=vector()
  s_count=0
  for(i in 1:length(DNAfile)){
    DNA=matrix(0,nrow=M+2)
    if(!is.na(DNAfile[[i]][1])){
      if(nchar(DNAfile[[i]][1])>2){
        if(substr(DNAfile[[i]][1],1,3)=="seg"){
          if(as.numeric(DNAfile[[i]][2])==0){
            s_count=s_count+1
            Output[[s_count]]=DNA
          }
          if(as.numeric(DNAfile[[i]][2])==1){
            s_count=s_count+1
            position=round(L*as.numeric(DNAfile[[i+1]][2]))
            DNA=matrix(0,nrow=M+2,ncol=1)
            for(k in 1:M){
              if(DNAfile[[i+1+k]][1]=="1"){
                DNA[k,1]=1
              }
            }
            DNA[(M+1),1]=max(position-1,0)
            DNA[(M+2),1]=position
            Output[[s_count]]=DNA
          }
          if(as.numeric(DNAfile[[i]][2])>1){
            s_count=s_count+1
            if(substr(DNAfile[[i+1]][1],1,3)=="pos"){
              position=as.numeric(DNAfile[[i+1]][2:length(DNAfile[[i+1]])])
              r_position=round(L* position)
              r_position_u=as.numeric(as.matrix(unique(r_position)))
            }
            if(length(r_position)>length(unique(r_position))){
              print("Length problem!Mutation appeared more than once on same site!")
              print("Extra mutation will be removed!")
            }
            DNA=matrix(0,nrow=M+2,ncol=length(r_position_u))
            DNA[(M+1),]=r_position_u-c(0,r_position_u[-length(r_position_u)])
            DNA[(M+2),]=r_position_u
            SEQ_data=vector()
            for(k in 1:M){
              SEQ_data=rbind(SEQ_data,as.numeric(as.vector(unlist(strsplit(DNAfile[[i+1+k]][1],"")))))
            }
            xy=match(r_position_u,r_position)
            DNA[1:M,]=SEQ_data[,xy]
            Output[[s_count]]=DNA
          }
        }
      }
    }
  }
  if(s_count==s){
    print("All sample were analysed")
  }
  return(Output)
}
