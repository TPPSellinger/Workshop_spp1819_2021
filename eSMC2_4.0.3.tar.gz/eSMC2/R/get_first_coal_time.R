#' Extract the first coalescent time from a .txt file containing genealogies in a newick format outputted by scrm
#' @param file : path to the file
#' @param mut : TRUE if mutation were simulated
#' @export
#' @return a matrix of 4 lines containing the index of first coalescent individual (line 1 and 2), the coalescent time (line 3) and the sequence length of the genealogy (line 4)
get_first_coal_time<-function(file,mut=F){
  data=Get_data(file,heavy=T)
  Output=matrix(0,nrow = 4, ncol= (length(data)))
  start=F
  end=F
  bonus=0
  for(i in 1:length(data)){
    if(length(substr(data[[i]],1,3))>0){
      if(start&mut&substr(data[[i]],1,3)[1]=="seg"){
        end=T
        Output=Output[,-c((i-start_i):(length(data)))]
      }
    }
    if(!end){
      if(start){
        if(length(which(strsplit(data[[i]],split = "")[[1]]=="]"))==1 & length(which(strsplit(data[[i]],split = "")[[1]]=="["))==1){
          Output[4,(i-start_i+bonus)]=as.numeric(substr(data[[i]],2,(gregexpr(data[[i]],pattern = "]")[[1]][1]-1)))
          for(xx in 1:length(as.numeric(gregexpr(data[[i]],pattern = ")")[[1]]))){
            id1=max(as.numeric(gregexpr(data[[i]],pattern = ",")[[1]])[which(as.numeric(gregexpr(data[[i]],pattern = ",")[[1]])<as.numeric(gregexpr(data[[i]],pattern = ")")[[1]][xx]))])
            if(xx==1){
              Output[1,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][min(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])>id1))]-1),(gregexpr(data[[i]],pattern = ":")[[1]][min(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])>id1))]-1)))
              Output[2,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]-1),(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]-1)))
              Output[3,(i-start_i+bonus)]=2*as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]+1),(id1-1)))
            }
            if(xx>1){
              if(id1>as.numeric(gregexpr(data[[i]],pattern = ")")[[1]][(xx-1)])){
                genealogy=data[[i]]
                if(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1))!=")"){
                  if(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]+1),(id1-1)))<(0.5*Output[3,(i-start_i+bonus)])){
                    Output[1,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][min(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])>id1))]-1),(gregexpr(data[[i]],pattern = ":")[[1]][min(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])>id1))]-1)))
                    Output[2,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]-1),(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]-1)))
                    Output[3,(i-start_i+bonus)]=2*as.numeric(substr(data[[i]],(gregexpr(data[[i]],pattern = ":")[[1]][max(which(as.numeric(gregexpr(data[[i]],pattern = ":")[[1]])<id1))]+1),(id1-1)))
                  }
                }
              }
            }

          }
        }else{
          stop("problem in data")
          nb_rec=length(which(strsplit(data[[i]],split = "")[[1]]=="]"))
          pos=which(strsplit(data[[i]],split = "")[[1]]=="]")
          Output=cbind(Output,matrix(0,nrow = 4, ncol= (nb_rec-1)))
          data_s=strsplit(data[[i]],split = "")[[1]]
          for(ii in 1:nb_rec){
            bonus=bonus+1
            Output[4,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(max(which(data_s[1:(pos[ii]-1)]=="["))+1),(pos[ii]-1)))
            Output[1,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ":")[[1]][1]-1),(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ":")[[1]][1]-1)))
            Output[2,(i-start_i+bonus)]=as.numeric(substr(data[[i]],(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ":")[[1]][2]-1),(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ":")[[1]][2]-1)))
            Output[3,(i-start_i+bonus)]=2*as.numeric(substr(data[[i]],(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ":")[[1]][1]+1),(gregexpr(paste(data_s[pos[ii]:length(data_s)],collapse =""),pattern = ",")[[1]][1]-1)))
          }
        }
      }
      if(length(data[[i]])>0){
        if(data[[i]]=="//"){
          start=TRUE
          start_i=i
        }
      }
    }

  }
  return(Output)
}
