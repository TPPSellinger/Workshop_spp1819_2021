#' Build signal for SMCm by merging a segrating SNP matrix and a segregating SMP matrix (index of both matrices must be the same)
#'
#' @param Os_SNP : segrating SNP matrix or list of segrating SNP matrix (for each scaffold/chromosome)
#' @param Os_SMP : segrating SMP matrix or list of segrating SMP matrix (for each scaffold/chromosome)
#' @export
#' @return : input data for SMCm
Merge_SMP_SNP<-function(Os_SNP,Os_SMP){
  if(is.list(Os_SNP)){
    nchr=length(Os_SNP)
    if(length(Os_SNP)!=length(Os_SMP)){
      stop("List don't have same size")
    }
    Os=list()
    M=dim(Os_SMP[[1]])[1]-2
    incoherent_positions=list()
    for(chr in 1:nchr){
      incoherent_positions_v=numeric()
      pos_rm=which(as.numeric(Os_SNP[[chr]][dim(Os_SNP[[chr]])[1],])%in%as.numeric(Os_SMP[[chr]][dim(Os_SMP[[chr]])[1],]))
      if(length(pos_rm)>0){
        pos_change_SMP=which(as.numeric(Os_SMP[[chr]][dim(Os_SMP[[chr]])[1],])%in%as.numeric(Os_SNP[[chr]][dim(Os_SNP[[chr]])[1],]))
        count_p=0
        count_problem=0
        for(pos in pos_change_SMP){
          count_p=count_p+1
          if(length(unique(Os_SNP[[chr]][which(Os_SMP[[chr]][1:M,pos]%in%c("U","M")),pos_rm[count_p]]))==1){
            pos_change=which(Os_SNP[[chr]][,pos_rm[count_p]]!=as.vector(unique(Os_SNP[[chr]][which(Os_SMP[[chr]][1:M,pos]%in%c("U","M")),pos_rm[count_p]])))
            Os_SMP[[chr]][pos_change,pos]=Os_SNP[[chr]][pos_change,pos_rm[count_p]]

          }else{
            #print("Incoherence between SNP and SMP data found")
            Os_SMP[[chr]][,pos]=Os_SNP[[chr]][,pos_rm[count_p]]
            #count_problem=count_problem+1
            incoherent_positions_v=c(incoherent_positions_v,as.numeric(Os_SNP[[chr]][dim(Os_SNP[[chr]])[1],pos_rm[count_p]]))
          }
        }
      }
      if(length(pos_rm)>0){
        print("Total number of incoherence between SNP and SMP:")
        print(count_problem)
        Os[[chr]]=cbind(Os_SMP[[chr]],Os_SNP[[chr]][,-pos_rm])
      }else{
        Os[[chr]]=cbind(Os_SMP[[chr]],Os_SNP[[chr]])
      }

      Os[[chr]]=Os[[chr]][,order(as.numeric(Os[[chr]][dim(Os[[chr]])[1],]))]
      incoherent_positions[[chr]]=incoherent_positions_v
    }


  }else{
    nchr=1
    if(is.list(Os_SMP)){
    stop("SNPs are in a Matrix but SMPs in a list")
    }
    M=dim(Os_SMP)[1]-2
    pos_rm=which(as.numeric(Os_SNP[dim(Os_SNP),])%in%as.numeric(Os_SMP[dim(Os_SMP),]))
    if(length(pos_rm)>0){
      pos_change_SMP=which(as.numeric(Os_SMP[dim(Os_SMP),])%in%as.numeric(Os_SNP[dim(Os_SNP),]))
      count_p=0
      for(pos in pos_change_SMP){
        count_p=count_p+1
        if(length(unique(Os_SNP[which(Os_SMP[1:M,pos]%in%c("U","M")),pos_rm[count_p]]))==1){
          pos_change=which(Os_SNP[,pos_rm[count_p]]!=as.vector(unique(Os_SNP[which(Os_SMP[1:M,pos]%in%c("U","M")),pos_rm[count_p]])))
          Os_SMP[pos_change,pos]=Os_SNP[pos_change,pos_rm[count_p]]

        }else{
          browser()
        }
      }
      Os=cbind(Os_SMP,Os_SNP[,-pos_rm])
    }else{
      Os=cbind(Os_SMP,Os_SNP)
    }

    Os=Os[,order(as.numeric(Os[dim(Os)[1],]))]
  }
  return(list(Os,incoherent_positions))
}
