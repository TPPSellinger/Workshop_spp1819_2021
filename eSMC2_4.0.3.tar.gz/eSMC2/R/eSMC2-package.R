## usethis namespace: start
#' @useDynLib eSMC2
#' @importFrom Rcpp sourceCpp
NULL
#> NULL
