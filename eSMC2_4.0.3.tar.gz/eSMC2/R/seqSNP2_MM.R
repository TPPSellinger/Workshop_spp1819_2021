#' Build signal for the model
#'
#' @param DNA : matrix of segregating sites for the whole sample
#' @param n : sequence length
#' @param M_a : Effective number of simultaneously analyzed sequences.
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm
#' @return : numeric vector in which the signal is encoded
seqSNP2_MM<-function(DNA,n,M_a=3,mask_island=10000){
  if(M_a==3){
    DNA=as.matrix(DNA)
    U_o=apply(DNA[1:M_a,],FUN=function(x){length(unique(x))},MARGIN = 2 )
    pos=which(U_o==2)
    seq=rep(0,n)
    if(length(pos)>0){
    for(o in 1:length(pos)){
      if(DNA[2,pos[o]]==DNA[3,pos[o]]){
        seq[as.numeric(DNA[5,pos[o]])]=1
      }
      if(DNA[1,pos[o]]==DNA[3,pos[o]]){
        seq[as.numeric(DNA[5,pos[o]])]=2
      }
      if(DNA[1,pos[o]]==DNA[2,pos[o]]){
        seq[as.numeric(DNA[5,pos[o]])]=3
      }
    }
    }
    theta=vector()
    for(xx in  1:(M_a-1)){
      for(yy in  (xx+1):M_a){
        theta=c(theta,seqSNP2_MH(DNA[c(xx,yy,(M_a+1),(M_a+2)),],n)$theta)
      }
    }
    mask_vector=(as.numeric(DNA[(M_a+2),-1])-as.numeric(DNA[(M_a+2),-dim(DNA)[2]]))-as.numeric(DNA[(M_a+2),-1])
    masked_pos=which(mask_vector>0)+1
    if(length(masked_pos)>0){
      for(cc in c(1,masked_pos)){
        if(cc==1){
          if(as.numeric(DNA[(M_a+1),cc])<(as.numeric(DNA[(M_a+2),cc])-1)){
            masked_number=as.numeric(DNA[(M_a+2),cc])-as.numeric(DNA[(M_a+1),cc])
            if(mask_island==1){
              seq[sample(c(1:(as.numeric(DNA[(M_a+2),1])-1)),masked_number)]=4
            }else{

              if(masked_number>mask_island){
                nb_island=floor(masked_number/mask_island)
                pos_island=sample(1:floor((as.numeric(DNA[(M_a+2),1])-1)/mask_island),nb_island)
                for(ppp in pos_island){
                  seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=4
                }

              }else{
                seq[1:masked_number]=4
              }

            }


          }
          if(any(is.na(seq))){
            browser()
          }
        }else{
          masked_number=mask_vector[(cc-1)]
          if(mask_island==1){
            seq[sample(c((as.numeric(DNA[(M_a+2),(cc-1)])+1):(as.numeric(DNA[(M_a+2),(cc)])-1)),masked_number)]=4
          }else{
            if(masked_number>mask_island){
              nb_island=floor(masked_number/mask_island)
              pos_island=sample(1:floor(((as.numeric(DNA[(M_a+2),cc])-1)-(as.numeric(DNA[(M_a+2),(cc-1)])+1))/mask_island),nb_island)
              for(ppp in pos_island){
                seq[((as.numeric(DNA[(M_a+2),(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[(M_a+2),(cc-1)]))+(ppp*mask_island))]=4
              }
            }else{
              seq[(as.numeric(DNA[(M_a+2),(cc-1)])+1):(as.numeric(DNA[(M_a+2),(cc-1)])+masked_number)]=4
            }

          }




          if(any(is.na(seq))){
            browser()
          }
        }

      }
    }
    n=length(which(as.numeric(seq)<4))
  }
  if(M_a==4){
    DNA=as.matrix(DNA)
    U_o=apply(DNA[1:M_a,],FUN=function(x){length(unique(x))},MARGIN = 2 )
    pos=which(U_o==2)
    seq=rep(0,n)
    for(o in 1:length(pos)){
      if(DNA[2,pos[o]]==DNA[3,pos[o]]&DNA[2,pos[o]]==DNA[4,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=1
      }
      else if(DNA[1,pos[o]]==DNA[3,pos[o]]&DNA[1,pos[o]]==DNA[4,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=2
      }
      else if(DNA[1,pos[o]]==DNA[2,pos[o]]&DNA[2,pos[o]]==DNA[4,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=3
      }
      else if(DNA[1,pos[o]]==DNA[2,pos[o]]&DNA[2,pos[o]]==DNA[3,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=4
      }
      else if(DNA[1,pos[o]]==DNA[2,pos[o]]&DNA[4,pos[o]]==DNA[3,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=5
      }
      else if(DNA[1,pos[o]]==DNA[3,pos[o]]&DNA[4,pos[o]]==DNA[2,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=6
      }
      else if(DNA[1,pos[o]]==DNA[4,pos[o]]&DNA[2,pos[o]]==DNA[3,pos[o]]){
        seq[as.numeric(DNA[6,pos[o]])]=7
      }
    }
    theta=vector()
    for(xx in  1:(M_a-1)){
      for(yy in  (xx+1):M_a){
        theta=c(theta,as.numeric(seqSNP2_MH(DNA[c(xx,yy,(M_a+1),(M_a+2)),])$theta))
      }
    }
    mask_vector=(as.numeric(DNA[(M_a+2),-1])-as.numeric(DNA[(M_a+2),-dim(DNA)[2]]))-as.numeric(DNA[(M_a+2),-1])
    masked_pos=which(mask_vector>0)+1
    if(length(masked_pos)>0){
      for(cc in c(1,masked_pos)){
        if(cc==1){
          if(as.numeric(DNA[(M_a+1),cc])<(as.numeric(DNA[(M_a+2),cc])-1)){
            masked_number=as.numeric(DNA[(M_a+2),cc])-as.numeric(DNA[(M_a+1),cc])
            if(mask_island==1){
              seq[sample(c(1:(as.numeric(DNA[(M_a+2),1])-1)),masked_number)]=8
            }else{

              if(masked_number>mask_island){
                nb_island=floor(masked_number/mask_island)
                pos_island=sample(1:floor((as.numeric(DNA[(M_a+2),1])-1)/mask_island),nb_island)
                for(ppp in pos_island){
                  seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=8
                }

              }else{
                seq[1:masked_number]=8
              }

            }


          }
          if(any(is.na(seq))){
            browser()
          }
        }else{
          masked_number=mask_vector[(cc-1)]
          if(mask_island==1){
            seq[sample(c((as.numeric(DNA[(M_a+2),(cc-1)])+1):(as.numeric(DNA[(M_a+2),(cc)])-1)),masked_number)]=8
          }else{
            if(masked_number>mask_island){
              nb_island=floor(masked_number/mask_island)
              pos_island=sample(1:floor(((as.numeric(DNA[(M_a+2),cc])-1)-(as.numeric(DNA[(M_a+2),(cc-1)])+1))/mask_island),nb_island)
              for(ppp in pos_island){
                seq[((as.numeric(DNA[(M_a+2),(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[(M_a+2),(cc-1)]))+(ppp*mask_island))]=8
              }
            }else{
              seq[(as.numeric(DNA[(M_a+2),(cc-1)])+1):(as.numeric(DNA[(M_a+2),(cc-1)])+masked_number)]=8
            }

          }




          if(any(is.na(seq))){
            browser()
          }
        }

      }
    }
    n=length(which(as.numeric(seq)<8))
  }


  output=list()

  theta=mean(theta)/(n/length(seq))
  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)
  return(output)
}
