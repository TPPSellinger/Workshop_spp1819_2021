#' Creates a multihetsep file from a Segregating matrix
#'
#' @param O : Segregating matrix
#' @param name : location  and name of the file
#' @param num : True if nucleotides are numeric (i.e 1 and 0)
#' @export
#' @return A file similar to ms output#
create_realinput_msmc2<-function(O,name,num=F){
  options(scipen=999)
  O=as.matrix(O)
  M=dim(O)[1]-2
  n=dim(O)[2]
  vect_opti=as.numeric(O[M+2,])
  O=O[-(M+2),]
  if(num){
    for(seq in 1:M){
      O1=as.numeric(O[seq,])
      Apos=which(O1==1)
      Tpos=which(O1==0)
      O1[Apos]="A"
      O1[Tpos]="T"
      O[seq,]=O1
    }
  }
  output=matrix(NA,nrow=length(vect_opti),ncol = 4)
  count=0
  for(p in 1:length(vect_opti)){
    diff=length(unique(O[1:M,p]))
    if(diff>1){
      count=count+1
      output[count,1]=1
      output[count,2]=as.numeric(format(as.numeric(vect_opti[p]),scientific = F))
      output[count,3]=as.integer(O[(M+1),p])
      output[count,4]=paste(O[1:M,p],collapse="")
    }
  }
  output=output[1:count,]
  if(length(vect_opti)>1){
    utils::write.table(output, file=paste(name,".txt",sep=""), quote = FALSE, row.names=FALSE, col.names=FALSE)
  }
  if(length(vect_opti)==1){
    utils::write.table(t(output), file=paste(name,".txt",sep=""), quote = FALSE, row.names=FALSE, col.names=FALSE)
  }
  options(scipen=0)
}
