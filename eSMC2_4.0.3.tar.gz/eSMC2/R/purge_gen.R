#' Purge the genealogy of a simulation from ghost event
#'
#' @param gen : output of get genealogy
#' @return genealogy purged from event occuring on less than 1 bp
purge_gen<-function(gen){
  if(min(as.numeric(gen$Coal_time[dim(gen$Coal_time)[1],]))<1){
    purge=which(as.numeric(gen$Coal_time[dim(gen$Coal_time)[1],])<1)
    gen$Coal_time=gen$Coal_time[,-purge]
    gen$id_create=gen$id_create[,-purge]
    gen$id_split=gen$id_split[,-purge]
    return(gen)
  }else{
    return(gen)
  }
}
