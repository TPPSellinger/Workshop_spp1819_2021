#' find index of a coalescent event
#'
#' @param id : index of individual coalescent
#' @param M : sample size (number of sequences)
#' @return numerical value giving coalescent event index for hidden state definition
find_index<-function(id,M=3){
  Mat_ind=matrix(0,ncol=2,nrow=1)
  for(ii in 1:(M-1) ){
    for(jj in (ii+1):M){
      Mat_ind=rbind(Mat_ind,c(ii,jj))
    }
  }
  Mat_ind=Mat_ind[-1,]
  Ind_v=paste(Mat_ind[,1],Mat_ind[,2],sep="")
  id_t=paste(id[1],id[2],sep="")
  ind=which(Ind_v==id_t)
  if(length(ind)==0){
    id_t=paste(id[2],id[1],sep="")
    ind=which(Ind_v==id_t)
  }
  return(ind)
}
