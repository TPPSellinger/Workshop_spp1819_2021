#'  Builds the HMM matrices of the new symbol
#'
#' Builds the HMM matrices to analysed the zip signal and calculate likelihood
#' @param A : Transition matrix
#' @param g : list of emission matrix for each external branch length
#' @param Mat_symbol_t : list of matrix symbol indication the zipping patterns
#' @param q : equilibrium probability
#' @param LH : TRUE to only build matrices for LH
#' @return A : 4 object list with matrices to calculate likelihood of zipped sequences
Build_MMzip_Matrix_mailund<-function(A,g,Mat_symbol_t,q,LH=F){
  C_t=list()
  TO_t=list()
  Q_t=list()
  Q__t=list()
  max_count=10
  for(TS in 1:length(g) ){
    E=g[[TS]]
    Mat_symbol=Mat_symbol_t[[TS]]
    C=list()
    TO=list()
    dd=(dim(Mat_symbol)[1])
    if(is.null(dd)){
      dd=0
    }
    l=vector(length =(dim(E)[2]+dd))
    Q=list()
    Q_=list()
    k=length(q)
    for(i in 1:dim(E)[2]){
      B=diag(x=E[,i])
      C[[i]]=Re(B%*%A)
      l[i]=1
      TO[[i]]=Re(t(A)%*%B)
      Q[[i]]=matrix(1,k,k)
      Q_[[i]]=matrix(1,k,k)
      if(any(C[[i]]<0)){stop()}
      if(any(TO[[i]]<0)){stop()}
    }
    x=length(C)
    mat_trick=eigen(TO[[1]])
    D=diag(mat_trick$values)
    if(dd>0){
      for(i in 1:dim(Mat_symbol)[1]){
        sx=strsplit(Mat_symbol[i,2]," ")
        sx=as.numeric(as.matrix(sx[[1]]))
        a=sx[1]
        b=sx[2]
        if(a==0){
          a=1
        }else{
          a=a+x-9-((TS-1)*max_count)
        }
        if(b==0){
          b=1
        }else{
          b=b+x-9-((TS-1)*max_count)
        }

        C[[(x+i)]]=Re(as.matrix(C[[b]])%*%as.matrix(C[[a]]))
        if(any(C[[(x+i)]]<0)){stop()}
        l[(i+dim(E)[2])]=(l[a]+l[b])
        l_temp=(l[a]+l[b])
        TO[[x+i]]=Re(TO[[a]]%*%TO[[b]])
        if(!LH){
          Q_temp=matrix(0,dim(D)[1],dim(D)[1])
          Q_temp_=matrix(0,dim(D)[1],dim(D)[1])
          for(x1 in 1:dim(D)[1]){
            for(x2 in 1:dim(D)[1]){
              if(D[x1,x1]!=D[x2,x2]){
                Q_temp[x1,x2]=((D[x1,x1]^(l_temp))-(D[x2,x2]^(l_temp)))/(D[x1,x1]-D[x2,x2] )
                Q_temp_[x1,x2]=sum((D[x1,x1]^seq(1,l_temp,1))*(D[x2,x2]^(l_temp-seq(1,l_temp,1))))
              }
              if(D[x1,x1]==D[x2,x2]){
                Q_temp[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp-1))
                Q_temp_[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp))
              }
            }
          }
          Q[[i+dim(E)[2]]]=Re(Q_temp)
          Q_[[i+dim(E)[2]]]=Re(Q_temp_)
        }
      }
    }
    if(dd==0){
      Q_=0
      Q=0
    }
    C_t[[TS]]=C
    TO_t[[TS]]=TO
    if(!LH){
    Q__t[[TS]]=Q_

    Q_t[[TS]]=Q
    }
  }
  output=list()
  output[[1]]=C_t
  output[[3]]=TO_t
  if(!LH){
  output[[2]]=Q__t

  output[[4]]=Q_t
   }
  return(output)
}
