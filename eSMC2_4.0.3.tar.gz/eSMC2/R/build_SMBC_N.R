#' Build the exact transition matrix from sequence of genealogy
#'
#' @param genealogy : Matrix of sequence of genealogy (output of get_first_coal_time)
#' @param Tc : numerical vector containing the discretization of time
#' @param M_a : number of haplotype used for model
#' @export
#' @return a square matrix of size TC counting the transition event
build_SMBC_N<-function(genealogy,Tc,M_a=3){
  vect_k=2:M_a
  nb_state=sum(choose(M_a,vect_k))
  Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
  for(i in 1:dim(genealogy)[2]){

    state=genealogy[1,i]
    if(i==1){

      former_state=state
      length_seq=genealogy[2,i]
      if(length_seq>1){
        #Output[former_state,state]=Output[former_state,state]+1

        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)

      }
    }else{
      length_seq=genealogy[2,i]
      if(length_seq>1){
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)

      }else{
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
      }
    }

  }
  return(Output)
}
