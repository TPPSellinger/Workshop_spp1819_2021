#'  Builds a numerical zip signal from the zip signal
#'
#' Transform the character sequence into a numeric vector
#' @param Os : output of zipping function
#' @param nb_context : number of different methylation context
#' @return A list with first object the ziped numerical sequence, as second the symbol matrix and as third the bp length of each symbol#
symbol2Num_m<-function(Os,nb_context=1){
  Mat_symbol=Os[[2]]
  Os=Os[[1]]
  output=list()
  if(is.list(Mat_symbol)){
  if(nb_context==1){
    zip_symbol=c(0,2)+1
  }
  if(nb_context==2){
    zip_symbol=c(0,2)+1
  }
  for(zip_o in zip_symbol){
    if(length(as.numeric(Mat_symbol[[zip_o]]))>0){
      for(i in 1:dim(Mat_symbol[[zip_o]])[1]){
        sym=strsplit(Mat_symbol[[zip_o]][i,2],"")
        sym=sym[[1]]
        sym=paste(sym,collapse=" ")
        Mat_symbol[[zip_o]][i,2]=sym
      }
      count=0
      used_letters=vector()
      for( i in letters){
        if(any(Mat_symbol[[zip_o]][,1]%in%i)){
          used_letters=c(used_letters,i)
          count=count+1
          pos=which(Os%in%i)
          x=as.numeric(which(letters%in%i))
          Os[pos]=(10*zip_o)+count
          Mat_symbol[[zip_o]][count,1]=(10*zip_o)+count
          sym=strsplit(Mat_symbol[[zip_o]][count,2]," ")
          sym=sym[[1]]
          if(sym[1]%in%letters){
            sym[1]=(10*zip_o)+as.numeric(which(used_letters==sym[1]))
          }
          if(sym[2]%in%letters){
            sym[2]=(10*zip_o)+as.numeric(which(used_letters==sym[2]))
          }
          sym=paste(sym,collapse=" ")
          Mat_symbol[[zip_o]][count,2]=sym
        }
      }
    }
  }


  output[[1]]=Os
  output[[2]]=Mat_symbol
  mat_length=0:((10*(length(zip_symbol)+1))-1)
  mat_length=cbind(mat_length,rep(0,length(mat_length)))
  l=rep(0,(10*(1+length(zip_symbol))))
  l[1:10]=1
  for(oo in 1:length(zip_symbol)){
    if(length(as.numeric(Mat_symbol[[oo]]))>0){
      for(i in 1:dim(Mat_symbol[[oo]])[1]){
        sx=strsplit(Mat_symbol[[oo]][i,2]," ")
        sx=as.numeric(as.matrix(sx[[1]]))
        a=sx[1]
        b=sx[2]
        if(b<10){
          b=b+1
        }
        if(a<10){
          a=a+1
        }
        new_l=l[a]+l[b]
        l[as.numeric(Mat_symbol[[oo]][i,1])]=new_l
      }
    }
  }
  mat_length[,2]=l
  output[[3]]=mat_length
  }else{
    if(nb_context==1){
      count=5
    }

    if(nb_context==2){
      count=8
    }
    for(i in 1:dim(Mat_symbol)[1]){
      sym=strsplit(Mat_symbol[i,2],"")
      sym=sym[[1]]
      sym=paste(sym,collapse=" ")
      Mat_symbol[i,2]=sym
    }

    for( i in LETTERS){
      if(any(Mat_symbol[,1]%in%i)){
        pos=which(Os%in%i)
        x=as.numeric(which(LETTERS%in%i))
        Os[pos]=(count+x)
        pos_i=which(Mat_symbol[,1]==i)
        Mat_symbol[pos_i,1]=count+x
        sym=strsplit(Mat_symbol[pos_i,2]," ")
        sym=sym[[1]]
        if(sym[1]%in%LETTERS){
          sym[1]=count+as.numeric(which(LETTERS%in%sym[1]))
        }
        if(sym[2]%in%LETTERS){
          sym[2]=count+as.numeric(which(LETTERS%in%sym[2]))
        }
        sym=paste(sym,collapse=" ")
        Mat_symbol[pos_i,2]=sym
      }
    }
    mat_length=c(as.character(0:(count)),Mat_symbol[,1])
    mat_length=cbind(mat_length,rep(0,length(mat_length)))
    l=rep(1,(count+1))
    for(i in 1:dim(Mat_symbol)[1]){
      sx=strsplit(Mat_symbol[i,2]," ")
      sx=as.numeric(as.matrix(sx[[1]]))
      a=sx[1]
      b=sx[2]
      new_l=l[a+1]+l[b+1]
      l=c(l,new_l)
    }
    mat_length[,2]=l

    output[[1]]=Os
    output[[2]]=Mat_symbol
    output[[3]]=mat_length
  }
  return(output)
}
