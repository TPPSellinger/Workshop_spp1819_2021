#' builds segregating matrix from msprime output file
#'
#' @param path : path to the output of msprime
#' @param M : number of happlotypes
#' @return A segregating matrix
read_msprime_data<-function(path,M){
  DNAfile=Get_data(path,simulator="msprime")
  DNA=matrix(0,ncol=length(DNAfile),nrow=M+2)
  #browser()
  for(i in 1:length(DNAfile)){
    pos=nchar(DNAfile[[i]][1])-2
    if(ceiling(as.numeric(substr(DNAfile[[i]][1],1,pos)))>DNA[(M+1),max(1,(i-1))]){
      DNA[(M+2),i]=ceiling(as.numeric(substr(DNAfile[[i]][1],1,pos)))
      if(i==1){
        DNA[(M+1),i]=DNA[(M+2),i]
      }else{
        DNA[(M+1),i]=as.numeric(DNA[(M+2),i])-as.numeric(DNA[(M+2),(i-1)])
      }

      DNA[1,i]=as.numeric(substr(DNAfile[[i]][1],nchar(DNAfile[[i]][1]),nchar(DNAfile[[i]][1])))
      for(ii in 2:M){
        DNA[ii,i]=as.numeric(substr(DNAfile[[i]][ii],1,1))
      }
    }
  }
    return(DNA)
}
