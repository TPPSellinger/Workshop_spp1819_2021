#' Builds the emission matrix of SMBC
#'
#' @param n : Hidden state number
#' @param mu : estimated mutation rate given prior
#' @param alpha : multiple merger parameter
#' @param M_a : effective number of simultaneously analyzedf sequence
#' @param Tc : expected coalescence times of each hiddens states
#' @param Ts_t : expected coalescence times of the external branch length
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param beta : germination rate
#' @param Beta : Original germination rate
#' @return A list containing all possible emission matrix of MSMC conditionned to the external branch length
build_emi_MM<-function(n=20,mu,alpha=1.99,M_a=3,Tc,Ts_t,mu_b=1,beta=1,Beta=1){

  g_t=list()
  for(i in 1:length(Ts_t)){
    Ts=Ts_t[[i]]#/(Beta*Beta)
    #print(mean(Ts))
    if(M_a==3){
      Ts=rep(Ts,length(Tc))
      if(any(Ts<(3*Tc))){
        Ts[which(Ts<(3*Tc))]<-3*Tc[which(Ts<(3*Tc))]
      }
      y=5
      g=matrix(nrow = (4*n),ncol=y)
      g[1:(3*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*Ts[1:(3*n)])
      g[(1:n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(1:n)])))
      g[(1:n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(1:n)])))
      g[(1:n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[(1:n)]-(2*Tc[(1:n)]))))

      g[((n+1):(2*n)),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((n+1):(2*n))])))
      g[((n+1):(2*n)),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((n+1):(2*n))]-(2*Tc[((n+1):(2*n))]))))
      g[((n+1):(2*n)),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((n+1):(2*n))])))

      g[(((2*n)+1):(3*n)),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[(((2*n)+1):(3*n))]-(2*Tc[(((2*n)+1):(3*n))]))))
      g[(((2*n)+1):(3*n)),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(((2*n)+1):(3*n))])))
      g[(((2*n)+1):(3*n)),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(((2*n)+1):(3*n))])))


      g[((3*n)+1):(4*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(((3*Tc[((3*n)+1):(4*n)]))))
      g[((3*n)+1):(4*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(((Tc[((3*n)+1):(4*n)])))))
      g[((3*n)+1):(4*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(((Tc[((3*n)+1):(4*n)])))))
      g[((3*n)+1):(4*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(((Tc[((3*n)+1):(4*n)])))))
      g[,5]=1

    }
    if(M_a==4){
      y=9
      Ts=rep(Ts,length(Tc))
      if(any(Ts<(4*Tc))){
        Ts[which(Ts<(4*Tc))]<-4*Tc
      }
      g=matrix(nrow =(11*n),ncol=y)
      lambda=beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha)))
      L3_2=3*(beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha))))
      L3=L3_2+((beta((3-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))

      g[((10*n)+1):(11*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(4*Tc[((10*n)+1):(11*n)]))
      g[((10*n)+1):(11*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*Tc[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*Tc[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*Tc[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*Tc[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),(6:8)]=0

      g[((6*n)+1):(10*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((6*n)+1):(10*n)]))
      g[((6*n)+1):(10*n),(6:8)]=0

      g[((6*n)+1):(7*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((6*n)+1):(7*n)]-(3*Tc[((6*n)+1):(7*n)]))))

      g[((7*n)+1):(8*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((7*n)+1):(8*n)])))
      g[((7*n)+1):(8*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((7*n)+1):(8*n)])))
      g[((7*n)+1):(8*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((7*n)+1):(8*n)]-(3*Tc[((7*n)+1):(8*n)]))))
      g[((7*n)+1):(8*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((7*n)+1):(8*n)])))

      g[((8*n)+1):(9*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((8*n)+1):(9*n)]-(3*Tc[((8*n)+1):(9*n)]))))
      g[((8*n)+1):(9*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((8*n)+1):(9*n)])))
      g[((8*n)+1):(9*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((8*n)+1):(9*n)])))
      g[((8*n)+1):(9*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((8*n)+1):(9*n)])))

      g[((9*n)+1):(10*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((9*n)+1):(10*n)]-(3*Tc[((9*n)+1):(10*n)]))))
      g[((9*n)+1):(10*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((9*n)+1):(10*n)])))
      g[((9*n)+1):(10*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((9*n)+1):(10*n)])))
      g[((9*n)+1):(10*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((9*n)+1):(10*n)])))

      g[1:(6*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[1:(6*n)]))

      g[1:n,2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[1:n])))
      g[1:n,3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[1:n])))
      g[1:n,4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[1:n]-(4*Tc[1:n])*0.5)+Tc[1:n])))
      g[1:n,5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[1:n]-(4*Tc[1:n])*0.5)+Tc[1:n])))
      g[1:n,6]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[1:(n)]))
      g[1:n,7]=0
      g[1:n,8]=0

      g[(n+1):(2*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(n+1):(2*n)])))
      g[(n+1):(2*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[(n+1):(2*n)]-(4*Tc[(n+1):(2*n)])*0.5)+Tc[(n+1):(2*n)])))
      g[(n+1):(2*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[(n+1):(2*n)])))
      g[(n+1):(2*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[(n+1):(2*n)]-(4*Tc[(n+1):(2*n)])*0.5)+Tc[(n+1):(2*n)])))
      g[(n+1):(2*n),6]=0
      g[(n+1):(2*n),7]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[(n+1):(2*n)]))
      g[(n+1):(2*n),8]=0

      g[((2*n)+1):(3*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((2*n)+1):(3*n)]-(4*Tc[((2*n)+1):(3*n)])*0.5)+Tc[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((2*n)+1):(3*n)]-(4*Tc[((2*n)+1):(3*n)])*0.5)+Tc[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),6]=0
      g[((2*n)+1):(3*n),7]=0
      g[((2*n)+1):(3*n),8]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((2*n)+1):(3*n)]))

      g[((3*n)+1):(4*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((3*n)+1):(4*n)]-(4*Tc[((3*n)+1):(4*n)])*0.5)+Tc[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((3*n)+1):(4*n)]-(4*Tc[((3*n)+1):(4*n)])*0.5)+Tc[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),6]=0
      g[((3*n)+1):(4*n),7]=0
      g[((3*n)+1):(4*n),8]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((3*n)+1):(4*n)]))

      g[((4*n)+1):(5*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((4*n)+1):(5*n)]-(4*Tc[((4*n)+1):(5*n)])*0.5)+Tc[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((4*n)+1):(5*n)]-(4*Tc[((4*n)+1):(5*n)])*0.5)+Tc[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),6]=0
      g[((4*n)+1):(5*n),7]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((4*n)+1):(5*n)]))
      g[((4*n)+1):(5*n),8]=0

      g[((5*n)+1):(6*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((5*n)+1):(6*n)]-(4*Tc[((5*n)+1):(6*n)])*0.5)+Tc[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((5*n)+1):(6*n)]-(4*Tc[((5*n)+1):(6*n)])*0.5)+Tc[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Tc[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),6]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((5*n)+1):(6*n)]))
      g[((5*n)+1):(6*n),7]=0
      g[((5*n)+1):(6*n),8]=0
      g[,9]=1
    }
    g_t[[i]]=g#/rowSums(g)

  }
  if(any(g<0)){browser()}
  return(g_t)
}
