#include <Rcpp.h>


using namespace Rcpp;
//' Forward Algorithm to compute likelihood
//'
//' @param Os : integer vector of observation
//' @param E : Emission matrix
//' @param q : equilibrium probability
//' @param C : Numeric Matrix, containing all pre calbulated probabilities from zipped observation
// [[Rcpp::export]]


double forward_cpp(Rcpp::IntegerVector const& Os, Rcpp::NumericMatrix const& E, Rcpp::NumericVector const& q,  Rcpp::NumericMatrix const& C) {
  int T_prime = Os.size();
  int n = q.size();
  Rcpp::NumericMatrix alpha(n, T_prime);
  double LH  = 0.0 ;
  double dn  = 0.0;
  int i=0;
  for(int l = 0; l < n; l++){
    alpha(l,i) = E(l,Os(i))*q[l];
    dn+=alpha(l,i);
  }
  LH+=log(dn);
  for(int l = 0; l < n; l++){
    alpha(l,i)=(alpha(l,i)/dn);
  }

  for(int i = 1; i < T_prime; i++){
    dn=0.0;
    for(int l = 0; l < n; l++){
      int x=(Os(i)*n)+l;
      alpha(l,i)=0;
      for(int k = 0; k < n ; k++){
        alpha(l,i) +=(C(x,k)*alpha(k,(i-1)));
      }
      dn+=alpha(l,i);
    }
    LH+=log(dn);
    for(int l = 0; l < n; l++){
      alpha(l,i)=(alpha(l,i)/dn);
    }
  }
  return LH ;
}
