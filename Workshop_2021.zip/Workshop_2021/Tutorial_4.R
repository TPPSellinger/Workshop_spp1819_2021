
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########

##############
# parameters #
##############

mu=10^-8 # mutation rate
L=10^7 # sequence length
M=4 # number of haploid genome 
r=10^-8 # recombination rate
nsim=1
Pop=10^4
setwd("~/Documents/Workshop_2021/msprime/")
shartp_v=c(2,5,10,50)
sharp=3
r_c=0
total_r=list()
Tc_r=list()
mu_ex=matrix(0,ncol = nsim,nrow=10)
rm_ex=matrix(0,ncol = nsim,nrow=10)
for(r in c(10^-9,10^-8,10^-7)){
  r_c=r_c+1
  strength=shartp_v[sharp]
  ER=T
  Pop_size=vector()
  x_ab=c(seq(0,1000,1),seq(1001,10^5,10),seq((1+10^5),10^7,10^3))
  total=list()
  Tc=list()

  for(t in x_ab){
    t=t/(4*Pop)
    Pop_t=Pop
    count=0
    if(t<=(100/(4*Pop))){
      Pop_t=Pop
    }
    if(t>(1000/(4*Pop))){
      Pop_t=Pop/strength
    }
    if(t>(10000/(4*Pop))){
      Pop_t=Pop
    }
    Pop_size=c(Pop_size,Pop_t)
  }
  for(x in 1:nsim){
    O_total=read_msprime_data(paste("Scenario_4_x",x,"_Strength_",strength,"_Length_",log10(L),"_rec_",-log10(r),"_m_",-(log10(mu)),".txt",sep ="" ),M)
    test=eSMC2(O=O_total,L=L,n=40)
    total[[(1+length(total))]]=as.numeric(test$Xi)
    Tc[[(1+length(Tc))]]=test$Tc
    rm_ex[r_c,x]=(test$rho/(test$mu))
    mu_ex[r_c,x]=test$mu
  }
  total_r[[r_c]]=total
  Tc_r[[r_c]]=Tc
}

if(T){
  gen <- 1
  name_sc=c(" Bottleneck")
  col_u=c("red","orange","green","blue","purple")
  plot(c(10,10^6),c(1,1), log=c("x"), ylim =c(2,6) , type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
  for(r_c in 1:3){
  for(x in 1:nsim){
    test_<-total_r[[r_c]][[x]]
    Pop_=mu_ex[r_c,x]/(mu)
    lines((Tc_r[[r_c]][[x]]*Pop_), log10((test_)*0.5*Pop_), type="s", col=col_u[r_c])
  }
  }
  lines(x_ab,log10(Pop_size), type="s", col="black")
  legend("topright",legend=c("r/mu=0.1","r/mu=1","r/mu=10"), col=col_u[1:3], lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
  #dev.off()
}
