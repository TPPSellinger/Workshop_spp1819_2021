install.packages("plot.matrix")
install.packages("devtools")
library(devtools)
path="~/Workshop_spp1819_2021/eSMC2_4.0.3.tar.gz" # Path to the dowloaded eSMC package
devtools::install_local(path)
