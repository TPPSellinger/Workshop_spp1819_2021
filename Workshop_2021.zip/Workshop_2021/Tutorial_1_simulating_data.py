################################
# Tutorial 1 : Simulating data #
################################
##################
# Requirements   #  
##################
import matplotlib
import numpy as np
from matplotlib import lines as mlines
from matplotlib import pyplot
import msprime

##############
# Parameters #
##############
sample_size=2 # Number of sampled (diploid) individuals 
Ne=10**4 # Effective population size 
r=1*1e-8 # Recombination rate
m=1*1e-8 # mutation rate
L=10 ** 8 # Sequence length
for strength in [5]: # Strength of the bottleneck
    demography=msprime.Demography()
    demography.add_population(initial_size=Ne) # Setting initial population size 
    demography.add_population_parameters_change(time=1000, population=None, initial_size=Ne/strength)
    demography.add_population_parameters_change(time=10000, population=None, initial_size=Ne)
    for x in range(1,11):
        ts=msprime.sim_ancestry(samples=sample_size,recombination_rate=r,sequence_length=L,demography=demography ,model=[msprime.DiscreteTimeWrightFisher(duration=1000),msprime.StandardCoalescent()]) # Simulating ancestry
        mts = msprime.sim_mutations(ts, rate=m) # Adding mutations  
        f = open("Scenario_1_x"+str(x)+"_Strength_"+str(strength)+"_Length_"+str(int(np.log10(L)))+"_rec_"+str(int(-np.log10(r)))+"_m_"+str(int(-np.log10(m)))+".txt","w") # writing file
        f.write("segsites: "+str(mts.get_num_sites())+'\n')
        f.write("//"+'\n')
        for tree in ts.trees():
            f.write("["+str(tree.span)+"]"+str(tree.newick())+'\n')
        f.close()
